<template>
  <div id="bar">
    <!-- <router-view/> -->
    <div>top</div>
  </div>
</template>

<script>
export default {
  name: 'bar'
}
</script>


