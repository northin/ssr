<template>
  <div id="bar" style="background:blue">
    <!-- <router-view/> -->
    <div>bar</div>
  </div>
</template>

<script>
export default {
  name: 'bar'
}
</script>


